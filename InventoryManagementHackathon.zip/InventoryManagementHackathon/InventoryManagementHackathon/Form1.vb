﻿Public Class Form1

    Private Row As Integer = 0

    Private Sub CheckBox_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged, CheckBox7.CheckedChanged, CheckBox8.CheckedChanged, CheckBox9.CheckedChanged, CheckBox10.CheckedChanged

        If sender.Checked = True Then

            Row = Int((sender.Location.Y - 175) / 36)

            Dim SenderYLocation As Integer = sender.Location.Y

            If MsgBox("Scan Retina", MsgBoxStyle.YesNo, "Scan Retina") = 6 Then

                For Each MyControl In Me.Controls

                    If MyControl.Location.Y = SenderYLocation Then

                        If MyControl.Location.X = 572 Then

                            MyControl.Text = "0.0"

                        End If

                        MyControl.Location = New Point(MyControl.Location.X, 322)

                    End If

                Next

                For Each MyControl In Me.Controls

                    If (Strings.Left(MyControl.Name, 5) = "Label" Or Strings.Left(MyControl.Name, 8) = "CheckBox") And (MyControl.Location.Y > Row * 36 + 175) Then

                        MyControl.Location = New Point(MyControl.Location.X, MyControl.Location.Y - 36)

                    End If

                Next

            End If

        End If

    End Sub

End Class